/**
 * Created by AnThen on 2016-7-21.
 * 数据质量报告 es6+react版
 */
'use strict';//严格模式

/*构造页面*/
import Layout from 'module/layout/layout';

/*先创建布局*/
const layout = new Layout({
    index: 1,
    leftMenuCurName:'数据质量报告'
});

/********插件********/
/*分页插件*/
let pagination = require('plugins/pagination')($);

/********本页全局公用变量********/

/********编写页面模块********/
class SubHead extends React.Component{
    fetch(){
        let that = this;
        util.api({
            url: "?method=mkt.data.quality.count.get",
            type: 'get',
            data: {},
            success: function (res) {
                if(res.code == 0){
                    that.setState({
                        subHead:{
                            total:res.data[0].total_rows,
                            issue:res.data[0].issue_rows,
                            modified:res.data[0].modified_rows
                        }
                    });
                }
            }
        });
    }
    constructor(props){
        super(props);
        this.state = {
            subHead:{total:0,issue:0,modified:0}
        };
    }
    componentDidMount(){
        this.fetch();
    }
    render(){
        return(
            <header className="page-body-header">
                <div className="text-box">
                    <span className="title">数据质量报告</span>
                    <span className="text">
                        共计接入数据<span className="variable">{this.state.subHead.total}</span>条&nbsp;|&nbsp;问题数据<span className="variable">{this.state.subHead.issue}</span>条&nbsp;|&nbsp;修复<span className="variable">{this.state.subHead.modified}</span>条
                    </span>
                </div>
                <div className="button-box icon iconfont">
                    <a className="a keyong" href={BASE_PATH+'/'} title="返回首页">&#xe644;</a>
                </div>
            </header>
        );
    }
}
class TbodyFalse extends React.Component{
    render() {
        return (
            <tbody>
                <tr>
                    <td style={{textAlign:'center',width:'100%'}} colSpan='8'>暂无数据！</td>
                </tr>
            </tbody>
        )
    }
}
class ModifyCount extends React.Component{
    render() {
        let log = this.props.log;
        if(log != ''){
            return (
                <div className="modify">
                    <a className="download" href={log.fileUrl} title={log.fileName}>{log.fileName}</a><span class="time">{log.handleTime}</span>
                </div>
            )
        }else{
            return (
                <div className="modify"></div>
            )
        }
    }
}
class IllegalCount extends React.Component{
    dropdownButton(){
        this.props.dropdown();
    }
    render() {
        if(this.props.illegal > 0){
            return (
                <div className="illegal">
                    <a href="javascript:void(0)" className="r-btn dropdown-button dropdown-button-illegal" data-activates="illegal-list" data-constrainwidth="false" data-gutter="-140" onMouseOver={this.dropdownButton.bind(this)}><num className="num">{this.props.illegal}</num><ico className="pointer icon iconfont">&#xe604;</ico></a>
                </div>
            )
        }else{
            return (
                <div className="illegal"></div>
            )
        }
    }
}
class TbodyTrue extends React.Component{
    dropdownButton(){
        $('.dropdown-button').dropdown({
            inDuration: 300,
            outDuration: 225,
            constrain_width: false,
            hover: false,
            gutter: 0,
            belowOrigin: false
        });
    }
    constructor(props){
        super(props);
        this.dropdownButton = this.dropdownButton.bind(this);
    }
    render() {
        return (
            <tbody>
            {this.props.data.map((m,i)=> {
                return (
                    <tr listid={m.id}>
                        <td className="first">
                            <div className="file-info">
                                <div className="file-type" title={m.fileTypeValue}>{m.fileTypeValue}</div>
                                <div className="underline">_</div>
                                <div className="file-source" title={m.sourceTileName}>{m.sourceTileName}</div>
                            </div>
                        </td>
                        <td><div className="sten-time">{m.startTime}</div></td>
                        <td><div className="sten-time">{m.endTime}</div></td>
                        <td><div className="data-source">{m.dataSource}</div></td>
                        <td><div className="lawful">{m.lawfulRecord}</div></td>
                        <td className="illegal-tr"><IllegalCount illegal={m.illegalRecord} dropdown={this.dropdownButton}/></td>
                        <td><ModifyCount log={m.modifyLog}/></td>
                        <td className="ico"><ico className="pointer icon iconfont r-btn dropdown-button moreico" data-activates="morelist" data-constrainwidth="false" listid={m.id} file-type={m.fileType} file-unique={m.fileUnique}>&#xe61a;</ico></td>
                    </tr>
                )
            })}
            </tbody>
        )
    }
}
class MoreList extends React.Component{
    render() {
        return (
            <ul id="morelist" className="dropdown-content setuplist">
                <li className="close">
                    <i className="icon iconfont">&#xe64e;</i>
                    <a className="a" href="javascript:void(0)">下载非法数据</a>
                </li>
                <li>
                    <i className="icon iconfont">&#xe60b;</i>
                    <a href="javascript:void(0)">查看日志</a>
                </li>
                <li className="upfile close">
                    <i className="icon iconfont">&#xe663;</i>
                    <a className="a" href="javascript:void(0)">修正后上传</a>
                    <input type="file" id="uploadFile" className="file" title="修正后上传"/>
                </li>
            </ul>
        )
    }
}
class IllegalList extends React.Component{
    constructor(props){
        super(props);
        this.state = {mobile:0,email:0,duplicate:0};
    }
    render() {
        return (
            <ul id='illegal-list' className='dropdown-content illegal-list'>
                <li>
                    <a href='javascript:void(0)'>非法手机号</a><num className='num'>{this.state.mobile}</num>
                </li>
                <li>
                    <a href='javascript:void(0)'>非法邮箱</a><num className='num'>{this.state.email}</num>
                </li>
                <li>
                    <a href='javascript:void(0)'>重复记录</a><num className='num'>{this.state.duplicate}</num>
                </li>
            </ul>
        )
    }
}
/********组织页面模块********/
class Manage extends React.Component {
    formatData(data){
        let tbodyData = new Array();
        let modifyLog = new Array();
        let thisUrl,thisName,handleTime,illegalRecord;
        for(let i=0; i<data.length; i++){
            modifyLog = data[i].modify_log || '';
            if(modifyLog.length > 0){
                thisName = (modifyLog[0].modify_file_name).split('/');
                thisName = thisName[thisName.length-1];
                thisUrl = FILE_PATH + modifyLog[0].modify_file_name;
                handleTime = modifyLog[0].handle_time;
                modifyLog = {
                    fileName: thisName,
                    fileUrl: thisUrl,
                    handleTime: handleTime
                };
            }else{modifyLog = '';}
            illegalRecord = parseInt(data[i].ilegal_data_rows_count);
            tbodyData[i] = {
                id: data[i].data_id,
                fileUnique: data[i].file_unique,
                fileType: data[i].file_type,
                fileTypeValue: data[i].file_type_value,
                sourceTileName: data[i].source_file_name,
                startTime: data[i].start_time,
                endTime: data[i].end_time,
                dataSource: data[i].data_source,
                lawfulRecord: data[i].legal_data_rows_count,
                illegalRecord: illegalRecord,
                modifyLog:modifyLog
            };
        }
        this.setState({tbodyModule:<TbodyTrue data={tbodyData}/>});
    }
    fetch(index,size){
        let that = this;
         util.api({
             url: "?method=mkt.data.quality.list.get",
             type: 'get',
             data: {'index':index,'size':size},
             success: function (res) {
                 if(res.code == 0){
                     if(res.data.length>0){
                         $('.pagination-wrap').pagination('updateItems', res.total_count);
                         that.formatData(res.data);
                     }
                 }
             }
         });
    }
    setPagination(){
        let that = this;
        if ($('.pagination-wrap').length > 0) {
            $('.pagination-wrap').pagination({
                items: 0,//条数
                itemsOnPage: 7,//最多显示页数
                onPageClick: function (pageNumber, event) {
                    that.fetch(pageNumber,7);
                }
            });
        }
    }
    constructor(props){
        super(props);
        this.state = {
            tbodyData: [],
            tbodyModule: <TbodyFalse />
        };
    }
    componentDidMount(){
        this.fetch(1,7);
        this.setPagination();
    }
    render() {
        return (
            <div className="quality-report">
                <SubHead />
                <div className="content">
                    <header className="header">
                        <div className="title">数据质量报告</div>
                        <div className="h2">您可以在此查看所有接入数据的质量并尝试修复它</div>
                    </header>
                    <div className="list-box">
                        <table className="page-table-box">
                            <thead>
                            <tr>
                                <th className="first">数据文件信息</th>
                                <th>开始时间</th>
                                <th>完成时间</th>
                                <th>数据源</th>
                                <th>合法记录</th>
                                <th>非法记录</th>
                                <th>修正记录</th>
                                <th className="ico"></th>
                            </tr>
                            </thead>
                            {this.state.tbodyModule}
                        </table>
                        <div className="pagination-wrap pagination light-theme simple-pagination"></div>
                    </div>
                    {/*菜单下拉*/}
                    <MoreList />
                    {/*非法记录下拉*/}
                    <IllegalList />
                </div>
            </div>
        )
    }
}
/********渲染页面********/
const manage = ReactDOM.render(
    <Manage />,
    document.getElementById('page-body')
);