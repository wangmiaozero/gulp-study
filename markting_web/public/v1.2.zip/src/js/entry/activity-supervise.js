/**
 * Created by AnThen on 2016-5-9.
 */
/*初始化必须的模块*/
'use strict';//严格模式

/*加载模块*/
//加载本页模块
var tpl = require("html/activity/supervise-tpl.html");
//组件
var Modals = require('component/modals.js');
let pagination = require('plugins/pagination')($);//分页插件

/*全局变量*/
var nowpage = {'tableType':'table4','campaignName':'','index':1,'size':7};

/*构造页面*/
var Layout = require('module/layout/layout');
//先创建布局
var layout = new Layout({
    index: 2,
    leftMenuCurName:'活动管理'
});

var Container = Backbone.View.extend({
//初始化model
    model: new Backbone.Model(),
//组织模块
    template:{
        templateMain: _.template($(tpl).filter('#tpl-content').html()),
        templateTbody: _.template($(tpl).filter('#tpl-tbody').html()),
        templateMorelist: _.template($(tpl).filter('#tpl-morelist').html())
    },
//设置响应事件
    events: {
        "click #activitySuperviseMoreList": "activitySuperviseMoreList",
        "keyup .activity-supervise-search-input": "activitySuperviseSearch",
        "click #activitySuperviseDelete": "activitySuperviseDelete",
        "click #search-ico": "searchShow",
        "keyup  #search-input": "searchHide",
        "blur  #search-input": "searchBlurHide",
        "click .tab-table": "changeTable"
    },
    tbodyBoxObjectWidth: function(){
        var tbodyBoxObject = $('#tbody-box').width() * 0.17;
        $('.tbody-box-object').css('width',tbodyBoxObject);
    },
    activitySuperviseMoreList: function(e){
        var that = $(e.currentTarget),
            thisParentsType = that.parents('tr').attr('trtype'),
            thatTrIndex = that.parents('tr').index(),
            thatIdnum = that.attr('idnum'),
            morelistFirstChildAHref = BASE_PATH+"/html/activity/analyse.html?id=",
            morelistFirstChild = $('#morelist').children('li:first-child'),
            morelistFirstChildA = morelistFirstChild.children('a'),
            morelistLastChild = $('#morelist').children('li:last-child');
        $('#morelist').attr({'trigger':thatTrIndex,'idnum':thatIdnum});
        switch (thisParentsType){
            case 'not-started':
                morelistFirstChild.addClass('close');
                morelistFirstChildA.attr('href','javascript:void(0)');
                morelistLastChild.removeClass('close');
                break;
            case 'bespoke':
                morelistFirstChild.addClass('close');
                morelistFirstChildA.attr('href','javascript:void(0)');
                morelistLastChild.addClass('close');
                break;
            case 'going':
                morelistFirstChild.removeClass('close');
                morelistFirstChildA.attr('href',morelistFirstChildAHref+thatIdnum);
                morelistLastChild.addClass('close');
                break;
            case 'over':
                morelistFirstChild.removeClass('close');
                morelistFirstChildA.attr('href',morelistFirstChildAHref+thatIdnum);
                morelistLastChild.removeClass('close');
                break;
        }
    },
    activitySuperviseSearch: function(e){
        /*
         var val = $(e.currentTarget).val().trim();
         var recentlyEl = $('.nodata', this.$el);
         var feedlistEl = $('.search-feeds', this.$el);
         if (val.length > 0) {
         recentlyEl.hide();
         feedlistEl.show();
         } else {
         recentlyEl.show();
         feedlistEl.hide();
         }
         if (val == 'age') {
         feedlistEl.html('<li class="count">共找到1条记录</li> <li>1. 风继续吹</li>');
         } else if (val == 'name') {
         feedlistEl.html('<li class="count">共找到3条记录</li> <li>1.2016年迎新活动</li> <li>1.2016年迎新活动</li> <li>1.2016年迎新活动</li>');
         } else {
         recentlyEl.show();
         feedlistEl.hide();
         }
         */
    },
    dropdownMorelist: function(){
        $('#morelist-box', this.$el).html(this.template.templateMorelist(this.model.toJSON()));
        $('.dropdown-button').dropdown({
            inDuration: 300,
            outDuration: 225,
            constrain_width: false,
            hover: false,
            gutter: 0,
            belowOrigin: false
        });
    },
    activitySuperviseDelete: function(e){
        var thisParentsType = $(e.currentTarget).parents('li').attr('class');
        if(thisParentsType != "close"){
            var that = this;
            new Modals.Confirm({
                content:"您确实要删掉这条信息吗？",
                listeners:{
                    close:function(type){
                        if(type){
                            var deleteIndex = parseInt($('#morelist').attr('trigger')),
                                deleteTrType = $('#tbody-box').children('tr').eq(deleteIndex).attr('trtype'),
                                deleteIdnum = parseInt($('#morelist').attr('idnum'));
                            var tabNotStart=parseInt($('#not-start-num').text()),
                                tabBespoke=parseInt($('#bespoke-num').text()),
                                tabGoing=parseInt($('#going-num').text()),
                                tabOver=parseInt($('#over-num').text()),
                                tabAll=parseInt($('#all-num').text());
                            util.api({
                                url: "?method=mkt.campaign.delete",
                                type: 'post',
                                data: {'campaign_head_id':deleteIdnum},
                                success: function (res) {
                                    if(res.msg == 'success'){
                                        $('#tbody-box').children('tr').eq(deleteIndex).empty().remove();
                                        that.dropdownMorelist();
                                        tabAll = tabAll - 1;
                                        switch (deleteTrType){
                                            case 'not-started':
                                                tabNotStart = tabNotStart - 1;
                                                $('#not-start-num').text(tabNotStart);
                                                break;
                                            case 'bespoke':
                                                tabBespoke = tabBespoke - 1;
                                                $('#bespoke-num').text(tabBespoke);
                                                break;
                                            case 'going':
                                                tabGoing = tabGoing - 1;
                                                $('#going-num').text(tabGoing);
                                                break;
                                            case 'over':
                                                tabOver = tabOver - 1;
                                                $('#over-num').text(tabOver);
                                                break;
                                        }
                                        $('#all-num').text(tabAll);
                                    }
                                }
                            });
                        }else{
//console.log("click cancel");
                        }
                    }
                }
            });
        };
    },
    searchShow: function () {
        var thisVal = $('#search-input', this.$el).val().trim();
        if(thisVal.length < 1){
            $('#search-input', this.$el).attr('disabled',false).addClass('show');
        }else{
            nowpage.campaignName = thisVal;
            this.tabTable(1,7);
            this.setPagination();
        }
    },
    searchHide: function () {
        var thisVal = $('#search-input', this.$el).val().trim();
        if(thisVal.length < 1){
            $('#search-input').val('').removeClass('show').attr('disabled',true);
        }
        nowpage.campaignName = thisVal;
        this.tabTable(1,7);
        this.setPagination();
    },
    searchBlurHide: function(){
        var thisVal = $('#search-input', this.$el).val().trim();
        if(thisVal.length < 1){
            $('#search-input').val('').removeClass('show').attr('disabled',true);
        }
    },
    changeTable: function(e){
        var thisType = $(e.currentTarget).attr('type');
        $('#search-input', this.$el).val('').removeClass('show');
        nowpage.tableType = thisType;
        nowpage.campaignName = '';
        this.tabTable(1,7);
        this.setPagination();
    },
    formatData: function(data,total){
        var tbodyData = new Array();
        var trurl,
            trurl1 = BASE_PATH+"/html/activity/plan.html?planId=",
            trurl2not = "&status=unreleased&returnurl=/html/activity/supervise.html",
            trurl2iss = "&status=released&returnurl=/html/activity/supervise.html",
            trurl2goov = "&status=active&returnurl=/html/activity/supervise.html";
        var status,
            status0 = "未启动",
            status1 = "已预约",
            status2 = "活动中",
            status3 = "已结束";
        var trtype;
        if(total>0){
            for(var i=0; i<total; i++){
                switch (data[i].publish_status){
                    case 0:
                        trurl = trurl1 + data[i].campaign_head_id + trurl2not;
                        status = status0;
                        trtype = 'not-started';
                        break;
                    case 1:
                        trurl = trurl1 + data[i].campaign_head_id + trurl2iss;
                        status = status1;
                        trtype = 'bespoke';
                        break;
                    case 2:
                        trurl = trurl1 + data[i].campaign_head_id + trurl2goov;
                        status = status2;
                        trtype = 'going';
                        break;
                    default:
                        trurl = trurl1 + data[i].campaign_head_id + trurl2goov;
                        status = status3;
                        trtype = 'over';
                        break;
                }
                tbodyData[i] = {
                    'campaign_head_id':data[i].campaign_head_id,
                    'campaign_name':data[i].campaign_name,
                    'trurl':trurl,
                    'status':status,
                    'trtype':trtype,
                    'create_time':data[i].create_time,
                    'start_time':data[i].start_time,
                    'end_time':data[i].end_time,
                    'segmentation_name':data[i].segmentation_name
                };
            }
        }
        $('#tbody-box', this.$el).html(this.template.templateTbody({tbodyData:tbodyData}));
    },
    tabTable: function(index,size){
        var that = this;
        var thisType = nowpage.tableType,campaignName = nowpage.campaignName;
        var publishStatus;
        switch (thisType){
            case "table0":
                publishStatus = 0;
                break;
            case "table1":
                publishStatus = 1;
                break;
            case "table2":
                publishStatus = 2;
                break;
            case "table3":
                publishStatus = 3;
                break;
            case "table4":
                publishStatus = 4;
                break;
        };
        /*ajax调用数据*/
        util.api({
            url: "?method=mkt.campaign.progressstatus.list.get",
            type: 'get',
            data: {'publish_status': publishStatus,'campaign_name': campaignName,'index':index,'size':size},
            success: function (res) {
                if(res.code == 0){
                    that.formatData(res.data,res.total);
                    $('.pagination-wrap').pagination('updateItems', res.total_count);
                }else{
                    that.formatData('',0);
                    $('.pagination-wrap').pagination('updateItems', res.total_count);
                }
                /*初始化表格'受众人群'列宽度*/
                that.tbodyBoxObjectWidth();
                /*重新初始化更多选项*/
                that.dropdownMorelist();
            }
        });
    },
    /*实例化分页插件*/
    setPagination() {
        var that = this;
        if ($('.pagination-wrap').length > 0) {
            $('.pagination-wrap').pagination({
                items: 0,//条数
                itemsOnPage: 7,//最多显示页数
                onPageClick: function (pageNumber, event) {
                    that.tabTable(pageNumber,7);
                }
            });
        }
    },
    initialize: function () {
        var that = this;
        this.render();
        this.model.on('change', function (m) {
            that.render();
        });
        this.tabTable(1,7);
    },
//组织完试图做的事情
    afterRender: function () {
        /*初始化页面头部说明部分*/
        util.api({
            url: "?method=mkt.campaign.summary.get",
            type: 'get',
            data: {},
            success: function (res) {
                var data = res.data;
                if(res.msg == 'success'){
                    $('#activity-num').html(data[0].total_campaign_count);
                    $('#audience-num').html(data[0].total_campaign_audience_count);
                }
            }
        });
        /*初始化各tab数量值*/
        util.api({
            url: "?method=mkt.campaign.progressstatus.count.get",
            type: 'get',
            data: {},
            success: function (res) {
                var data = res.data;
                if(res.msg == 'success'){
                    $('#not-start-num').text(data[0].count);
                    $('#bespoke-num').text(data[1].count);
                    $('#going-num').text(data[2].count);
                    $('#over-num').text(data[3].count);
                    $('#all-num').text(data[4].count);
                }
            }
        });
    },
//组织视图模板
    render: function () {
//加载主模板
        $('#page-body', this.$el).html(this.template.templateMain(this.model.toJSON()));
        this.setPagination();
        this.afterRender();
        return this;
    }
})    ;

/************生成页面************/
var container = new Container({
    el: '#container'
});