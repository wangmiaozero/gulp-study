/**
 * Created by 刘晓帆 on 2016-4-11.
 * 测试功能专用1
 */
'use strict';

//组件
var Modals = require('component/modals.js');
// var Lcalendar = require('module/lcalendar/lcalendar.js');
var MyCavans = require('module/test/canvastest.js');
/*构造页面*/
var Layout = require('module/layout/layout');
//先创建布局1 2
var layout = new Layout({
    index: 0,
    leftMenuCurName: ''
});

//root
class Test extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            totalCount: 0//
        }

        // this.setTotal = this.setTotal.bind(this)
    }

    //相当于backbone的事件代理机制
    events() {
        this.$el.on('click', '#test-confirm', this.showConfirm);
        // this.$el.on('click', '#test-confirm', this.showConfirm);

    }

    //模拟confirm弹窗
    showConfirm() {
        new Modals.Confirm({
            content: "I am Confirm !",
            listeners: {
                close: function (type) {
                    if (type) {
                        console.info("click Ok ")
                    }
                }
            }
        });
    }

    load() {
        let that = this;
        that.setState({
            totalCount: 1
        });
        util.api({
            data: {
                //method: "mkt.data.main.searchbyid.get",
                method: "mkt.data.main.search.get",
                name: '未命名'
            },
            success: function (res) {

                // console.info('', res)
            }
        });
        //util.api({
        //    url: "?method=mkt.data.filter.audiences.get",
        //    type: 'post',
        //    data: {
        //        //"segment_name": "母婴北京vip",
        //        //"publish_status": 0,
        //        md_type: 0,
        //        "task_ids":[1],
        //        "contact_ids":[1],
        //
        //    },
        //    success: function (res) {
        //        console.info(res)
        //    }
        //});
    }

    // 实例化后执行一次,相当于init方法
    componentDidMount() {
        this.$el = $(React.findDOMNode(this));
        this.events();//规范的写法已经放弃了backbone的这种方式了，慎用
        this.load();
    }

    //每次渲染之后都要调用
    componentDidUpdate() {
        var clipboard = new Clipboard('.btn');
        clipboard.on('success', function (e) {
            console.info('Action:', e.action);
            console.info('Text:', e.text);
            console.info('Trigger:', e.trigger);
            e.clearSelection();
        });
    }

    render() {
        return (
            <div className="test">
                <div className="clearfix">
                </div>
                <div className="row">
                    <button id="test-confirm" className="btn">confirm</button>
                </div>
                <MyCavans/>
                <div className="row">
                    <div className="testtitle copy-btn btn" data-clipboard-text="http://www.baidu.com">copy</div>
                </div>
                <div className="row">
                    <p>
                        <input className="type1" name="group3" type="radio" id="test5" checked />
                        <label for="test5">Red</label>
                    </p>
                </div>
            </div>
        )
    }
}

//渲染
const test = ReactDOM.render(
    <Test />,
    document.getElementById('page-body')
);
let str = "API_PATH: 'http://mktdevsrv.rc.dataengine.com/api',//AJAX路径-dev";
let regExp = /^API_PATH:(.*)com$/;
console.info(str.replace(regExp, 'http://baidu.com'));



module.exports = Test;