/**
 * Created by AnThen on 2016-5-9.
 */
/*初始化必须的模块*/
'use strict';//严格模式

/*加载模块*/
//加载本页模块
var tpl = require("html/audience/crowd-tpl.html");

//组件
var Modals = require('component/modals.js');
var TableList = require('module/table-list/table-list');//通用表格模块
/*构造页面*/
var Layout = require('module/layout/layout');
//先创建布局
var layout = new Layout({
    index: 2,
    leftMenuCurName: '人群管理'
});

var Container = Backbone.View.extend({
    //初始化model
    model: new Backbone.Model(),
    //组织模块
    template: {
        templateMain: _.template($(tpl).filter('#tpl-content').html()),
        templateMorelist: _.template($(tpl).filter('#tpl-morelist').html())
    },
    //设置响应事件
    events: {
        "click #showgrouplist": 'showgrouplist',//弹出搜索用户
        "click .dropdown-button-more": "showMorelist",
        "click #delete-crowd-info": "deleteInfo"
    },
    showgrouplist:function(e){
        var listid = $(e.currentTarget).parents('#morelist').attr('listid'),
            crowdNum = $('tr[listid='+listid+']').children('td').eq(1).text() || 0;
        /**
         * 弹出搜索用户窗口
         * 第1个参数e必须传，不然无法显示。
         * 第2个参数是ajax的data和总数
         */
        layout.showgrouplist(e, {
            data:{
                method: "mkt.audience.search.get",
                audience_type: 1,//0全局，1人群，2自定义标签
                audience_id: listid,//人群id
            },
            total_count: crowdNum//总数，如果没有总数就注释掉这行
        });
    },
    resetMorelist: function(){
        $('#morelist-box', this.$el).html(this.template.templateMorelist(this.model.toJSON()));
        $('.dropdown-button').dropdown({
            inDuration: 300,
            outDuration: 225,
            constrain_width: false,
            hover: false,
            gutter: 0,
            belowOrigin: false
        });
    },
    showMorelist: function(e){
        var listid = $(e.currentTarget).attr('listid');
        $('#morelist').attr('listid',listid);
    },
    deleteInfo: function () {
        var that = this;
        var listid;
        new Modals.Confirm({
            content: "您确实要删掉这条信息吗？",
            listeners: {
                close: function (type) {
                    if (type) {
                        listid = that.tableList.trData.audience_list_id;//这样取TR这条数据的ID
                        util.api({
                            url: "?method=mkt.audience.list.delete",
                            type: 'post',
                            data: {'audience_list_id':listid},
                            success: function (res) {
                                if(res.msg == 'success'){
                                    $('#tbody-box').children('tr[listid='+listid+']').empty().remove();
                                    that.resetMorelist();
                                }
                            }
                        });
                    } else {
                        //console.log("click cancel");
                    }
                }
            }
        });
    },
    fetchSubHead: function(){
        var audienceCount,audiencePeopleCount;
        util.api({
            url: "?method=mkt.audience.count.get",
            type: 'get',
            success: function (res) {
                if(res.code == 0){
                    audienceCount = res.data[0].audienceCount;
                    audiencePeopleCount =res.data[0].audiencePeopleCount;
                    audiencePeopleCount = _.str.numberFormat(audiencePeopleCount)
                    $('#audience').text(audienceCount);
                    $('#audience-people').text(audiencePeopleCount)
                }
            }
        });
    },
    initialize: function () {
        var that = this;
        this.render();
        this.model.on('change', function (m) {
            that.render();
        });
        this.fetchSubHead();
        this.setComponent();
    },
    //配置组件
    setComponent: function () {
        var that = this;
        /*表格模块*/
        this.tableList = new TableList({
            el: '.table-list-wrap',
            size: 7
        });
        this.tableList.on('afterrender',function (model) {
            that.resetMorelist();
        })
    },

    //组织视图模板
    render: function () {
        //加载主模板
        $('#page-body', this.$el).html(this.template.templateMain(this.model.toJSON()));
        return this;
    }
});

/************生成页面************/
var container = new Container({
    el: '#container'
});