/**
 * Created by richard on 2016-9-5.
 * 登录
 */
'use strict';//严格模式

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userName: '',
            passWord: '',
            showErr: false,
            showUserNameClear: false,
            showPassWordClear: false

        }
    }

    submit() {
        let that = this;
        util.api({
            url: "?method=mkt.user.login",
            type: 'post',
            data: {'user_id': this.state.userName, 'password': this.state.passWord},
            success: function (res) {
                if (res.code === 0) {
                    // var address = geturlparam('from');
                    localStorage.setItem('user_token', res.jsessionid || 1);
                    localStorage.setItem('user_id', that.state.userName);
                    window.location.href = '/';
                    // if (address) {
                    //     window.history.go(-1);
                    // } else {
                    //     window.location.href = '/'
                    // }
                } else {
                    that.setState({
                        showErr: true
                    })
                }
            }
        });
    }

    clearUserName() {
        this.setState({
            userName: '',
            showUserNameClear: false
        });
    }

    clearPassWord() {
        this.setState({
            passWord: '',
            showPassWordClear: false
        });
    }

    changeUserName(e) {
        let val = e.target.value || '';
        this.setState({
            userName: val,
            showUserNameClear: val ? true : false
        });

    }

    changePassWord(e) {
        let val = e.target.value || '';
        this.setState({
            passWord: val,
            showPassWordClear: val ? true : false
        });
    }

    render() {
        let showErrClass = this.state.showErr ? '' : 'fn-hide';
        let showUserNameClear = this.state.showUserNameClear ? '' : 'fn-hide';
        let showPassWordClear = this.state.showPassWordClear ? '' : 'fn-hide';
        return (
            <div>
                <div className="header">
                    <div className="menuwrap clearfix">
                        <div className="logowrap left"></div>
                        <div className="title left">营销云</div>
                    </div>
                </div>
                <div className="con">
                    <div className="formwrap">
                        <div className="input-block">
                            <ico className="icon iconfont user"></ico>
                            <ico className={"icon iconfont cleartext "+showUserNameClear}
                                 onClick={this.clearUserName.bind(this)}>
                            </ico>
                            <input type="text" className="validate"
                                   placeholder="请输入您的用户名" value={this.state.userName}
                                   onChange={this.changeUserName.bind(this)}
                            />
                        </div>
                        <div className="input-block">
                            <ico className="icon iconfont password"></ico>
                            <ico className={"icon iconfont cleartext "+showPassWordClear}
                                 onClick={this.clearPassWord.bind(this)}>
                            </ico>
                            <input type="password" className="validate"
                                   placeholder="请输入您的密码"
                                   value={this.state.passWord}
                                   onChange={this.changePassWord.bind(this)}
                            />
                            <div className={"errtip "+showErrClass}>
                                <div className="txt left">用户名或密码错误！</div>
                                <ico className="icon iconfont right">&#xe645;</ico>
                            </div>
                        </div>
                        <div className="btn submit" onClick={this.submit.bind(this)}>登录</div>
                    </div>
                </div>
            </div>
        )
    }
}
//渲染
const login = ReactDOM.render(
    <Login />,
    document.getElementById('login')
);

export default Login;