/**
 * Created by 刘晓帆 on 2016-4-11.
 * 首页1
 */
'use strict';
import Layout from 'module/layout/layout';
import Lcalendar from 'module/lcalendar/lcalendar';
let EChartsAxis = require('module/echarts/echarts-axis.js');
let EChartsAnnular = require('module/echarts/echarts-annular.js');

const layout = new Layout({
    index: 0,
    leftMenuCurName: ''
});



class Index extends React.Component {
    eserExpandingTrendChart() {
        let myChart = echarts.init(document.getElementById('eser-expanding-trend-chart'));
        myChart.showLoading();
        let data;
        let xAxis=[],series=[],seriesData=[];
        let chartsData = {
            div: myChart,
            divId:$('#eser-expanding-trend-chart'),
            title: '用户累计趋势',
            backgroundColor: ['#5bd4c7'],
            formatter: '{b}：{c}人',
            xAxis: [],
            yAxisUnit:'{value} 人',
            series: []
        };
        util.api({
            data: {method: 'mkt.homepage.usercount.list'},
            success: function (res) {
                if(res.code == 0){
                    data = res.data[0];
                    if(data.length > 0){
                        for(let i=0; i<data.length; i++){
                            xAxis[i] = data[i].month;
                            seriesData[i] = data[i].month_count;
                        }
                        series[0] = {name:'',data:seriesData};
                        chartsData.xAxis = xAxis;
                        chartsData.series = series;
                    }
                    EChartsAxis.axis(chartsData);
                }
            }
        });
    }

    mainDataSource() {
        let myChart = echarts.init(document.getElementById('main-data-source'));
        myChart.showLoading();
        let resData;
        let data=[];
        let chartsData = {
            div: myChart,
            divId:$('#main-data-source'),
            title: '用户来源',
            data: []
        };
        util.api({
            data: {method: 'mkt.homepage.datasource.list'},
            success: function (res) {
                if(res.code == 0){
                    resData = res.data[0];
                    for(let i=0; i<resData.length; i++){
                        data[i] = {value:resData[i].source_count,name:resData[i].source};
                    }
                    chartsData.data = data;
                    EChartsAnnular.annular(chartsData);
                }
            }
        });
    }

    constructor(props) {
        super(props);
        this.state = {
            datainfo: [
                {
                    "id": 1,
                    "name": "接入数据",
                    "count": 0,
                    "link_name": "数据接入"
                },
                {
                    "id": 2,
                    "name": "标签",
                    "count": 0,
                    "link_name": "标签管理"
                },
                {
                    "id": 3,
                    "name": "可触达用户",
                    "count": 0,
                    "link_name": "数据洞察"
                },
                {
                    "id": 4,
                    "name": "细分人群",
                    "count": 0,
                    "link_name": "细分管理"
                },
                {
                    "id": 5,
                    "name": "已结束活动",
                    "count": 0,
                    "link_name": "活动管理"
                },
                {
                    "id": 6,
                    "name": "进行活动",
                    "count": 0,
                    "link_name": "活动编排"
                }
            ]
        };
        // this.setTotal = this.setTotal.bind(this)
    }

    loadDataInfo() {
        let that = this;
        util.api({
            data: {
                method: 'mkt.homepage.datacount.list'
            },
            success(response){
                if (response.code == 0) {
                    that.setState({
                        datainfo: response.data[0]
                    })
                }
            }
        })
    }

    componentDidMount() {
        this.loadDataInfo();
        this.eserExpandingTrendChart();
        this.mainDataSource();
    }

    render() {
        let datainfo = this.state.datainfo;
        return (
            <div className="index">
                <div className="row">
                    <div className="col s9">
                        <div className="block mr10 h280" style={{padding:'24px 20px;'}}
                             id="eser-expanding-trend-chart"></div>
                    </div>
                    <div className="col s3">
                        <div className="block ml10 wrap-rt">
                            <div className="info-box-r">
                                <div className="hd clearfix">
                                    <div className="left">{datainfo[0].name}</div>
                                    <div className="right"><a href="/html/data-access/file.html">数据接入</a></div>
                                </div>
                                 <div className="bd clearfix">
                                    <div className="left txt">{_.str.numberFormat(datainfo[0].count)}</div>
                                    <div className="right">
                                        <img src="/img/index/zs-b.png" alt=""/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="block ml10 wrap-rb">
                            <div className="info-box-r">
                                <div className="hd clearfix">
                                    <div className="left">{datainfo[1].name}</div>
                                    <div className="right"><a href="/html/label-management/system.html" className="bg-green">标签管理</a></div>
                                </div>
                                <div className="bd clearfix">
                                    <div className="left txt">{_.str.numberFormat(datainfo[1].count)}</div>
                                    <div className="right"><img src="/img/index/zs-g.png" alt=""/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s3">
                        <div className="block mr10 h100">
                            <div className="info-box bg-green">
                                <div className="hd clearfix">
                                    <div className="left">{datainfo[2].name}</div>
                                    <div className="right"><a href="/html/data-supervise/master-data.html">主数据</a></div>
                                </div>
                                <div className="bd clearfix">
                                    <div className="left txt">{_.str.numberFormat(datainfo[2].count)}</div>
                                    <div className="right"><img src="/img/index/zs.png" alt=""/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s3">
                        <div className="block mr10 ml10 h100">
                            <div className="info-box bg-purple">
                                <div className="hd clearfix">
                                    <div className="left">{datainfo[3].name}</div>
                                    <div className="right"><a href="/html/audience/manage.html">细分管理</a></div>
                                </div>
                                <div className="bd clearfix">
                                    <div className="left txt">{_.str.numberFormat(datainfo[3].count)}</div>
                                    <div className="right"><img src="/img/index/zs.png" alt=""/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s3">
                        <div className="block mr10 ml10 h100">
                            <div className="info-box bg-yellow">
                                <div className="hd clearfix">
                                    <div className="left">{datainfo[4].name}</div>
                                    <div className="right"><a href="/html/activity/supervise.html">活动管理</a></div>
                                </div>
                                <div className="bd clearfix">
                                    <div className="left txt">{_.str.numberFormat(datainfo[4].count)}</div>
                                    <div className="right"><img src="/img/index/zs.png" alt=""/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s3">
                        <div className="block ml10 h100">
                            <div className="info-box bg-blue">
                                <div className="hd clearfix">
                                    <div className="left">{datainfo[5].name}</div>
                                    <div className="right"><a href="/html/activity/supervise.html">活动管理</a></div>
                                </div>
                                <div className="bd clearfix">
                                    <div className="left txt">{_.str.numberFormat(datainfo[5].count)}</div>
                                    <div className="right"><img src="/img/index/zs.png" alt=""/></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s4">
                        <div className="block mr10 h346" style={{padding:'24px 20px;'}} id="main-data-source"></div>
                    </div>
                    <div className="col s8">
                        <div className="block ml10 h346">
                            <div className="title">活动日历</div>
                            <Lcalendar/>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


//渲染
const index = ReactDOM.render(
    <Index />,
    document.getElementById('page-body')
);
module.exports = Index;