/**
 * Created by AnThen on 2016-5-10.
 */
/*初始化必须的模块*/
'use strict';//严格模式

/*加载模块*/
let pagination = require('plugins/pagination')($);//分页插件
//加载本页模块
var tpl = require("html/label-management/system-tpl.html");

/*构造页面*/
var Layout = require('module/layout/layout');
//先创建布局
var layout = new Layout({
    index: 1,
    leftMenuCurName:'系统标签'
});
/*分页参数*/
var nowpage = {"tag_group_id":1,"index":1,"size":7};

var Container = Backbone.View.extend({
    //初始化model
    model: new Backbone.Model({lableMenu:"",lableData:[]}),
    //组织模块
    template: {
        templateMain: _.template($(tpl).filter('#tpl-content').html()),
        templateLablelist: _.template($(tpl).filter('#tpl-lablelist').html()),
        templateTable: _.template($(tpl).filter('#tpl-table').html()),
        templateSetuplist: _.template($(tpl).filter('#tpl-setuplist').html())
    },
    //设置响应事件
    events: {
        "click #sync": "sync",
        "click .groupid": "menuResetTable",
        "mouseover .dropdown-button-more": "fetchMoreData"
    },
    /*初始化标签menu下拉功能*/
    initializeDropdown: function(obj){
        $(obj).dropdown({
            inDuration: 300,
            outDuration: 225,
            constrain_width: false,
            hover: false,
            gutter: 0,
            belowOrigin: false
        });
    },
    /*整理标签menu*/
    formatLableMenu: function(data,total){
        var lableData = new Array();

        for(var i=0; i<total; i++){
            lableData[i] = [data[i].select_name,data[i].id];
        }
        this.model.set({lableMenu: lableData[0][0],lableData: lableData});
        /*标签分类下拉初始化*/
        this.initializeDropdown('.lablelist');
    },
    /*整理table数据*/
    formatLableData: function(data,total){
        var lableData = new Array();
        for(var i=0; i<total; i++){
            lableData[i] = {"id":data[i].tag_group_id,"name":data[i].tag_group_name,"num":data[i].tag_count};
        }
        $('#tbody-box', this.el).html(this.template.templateTable({tableData:lableData}));
    },
    sync: function(e){
        var that = this;
        $('#sync').addClass('sync');
        setTimeout(function(){
            that.fetchTableData(1,7,true);
        },2000);
    },
    initialize: function () {
        var that = this;
        this.render();
        this.model.on('change', function (m) {
            that.render();
        });
        /*标签分类初始化*/
        this.fetchLableData();
    },
    /*获取标签分类menu*/
    fetchLableData: function () {
        var that = this;
        util.api({
            url: '?method=mkt.taggroup.system.menulist.get',
            type: 'get',
            data: {},
            success: function (res) {
                if(res.code == 0){
                    that.formatLableMenu(res.data,res.total_count);
                    /*表格模块*/
                    nowpage.tag_group_id = res.data[0].id;
                    that.fetchTableData();
                }
            }
        });
    },
    /*更新table*/
    menuResetTable: function(e){
        var thisGroupid = $(e.currentTarget).attr('groupid'),thisName = $(e.currentTarget).text();
        nowpage = {'tag_group_id':thisGroupid,'index':1,'size':7};
        $('#selectTtxt').empty().text(thisName);
        this.fetchTableData();
    },
    /*获取table值*/
    fetchTableData: function(index,size,renewfetch){
        var that = this;
        var id = nowpage.tag_group_id,thisIndex = index || nowpage.index,thisSize = size || nowpage.size;
        util.api({
            url: '?method=mkt.taggroup.system.list.get',
            type: 'get',
            data: {
                tag_group_id: id,
                index: thisIndex,
                size: thisSize
            },
            success: function (res) {
                if(res.code == 0){
                    that.formatLableData(res.data,res.total);
                    $('.pagination-wrap').pagination('updateItems', res.total_count);
                    if(renewfetch){
                        $('#sync').removeClass('sync');
                        Materialize.toast('标签已更新！',2000,'toast');
                    }
                }
            }
        });
    },
    /*获取table更多选项值*/
    fetchMoreData: function(e){
        var that = this;
        if(!$(e.currentTarget).hasClass('stop')){
            var listid = $(e.currentTarget).attr('listid');
            //$('#setuplist', that.el).empty();
            util.api({
                url: "?method=mkt.tag.system.list.get",
                type: 'get',
                data: {"tag_group_id":listid},
                success: function (res) {
                    if(res.code == 0){
                        $('#setuplist', that.el).html(that.template.templateSetuplist({setupListData:res.data}));
                        that.initializeDropdown('.dropdown-button-more');
                    }
                }
            });
        }
    },
    /*实例化分页插件*/
    setPagination() {
        var that = this;
        if ($('.pagination-wrap').length > 0) {
            $('.pagination-wrap').pagination({
                items: 0,//条数
                itemsOnPage: 7,//最多显示页数
                onPageClick: function (pageNumber, event) {
                    that.fetchTableData(pageNumber,7);
                }
            });
        }
    },
    afterRender: function () {
        if ($('#mymodal').length == 0) {
            $('body').append('<div id="mymodal" class="modal"></div>');
        }
        /*初始化页面说明部分*/
        util.api({
            url: "?method=mkt.tag.system.tagcount.get",
            type: 'get',
            data: {},
            success: function (res) {
                if(res.msg == 'success'){
                    $('#tag-count').html(res.data[0].tag_count);
                    $('#sync-time').html(res.data[0].sync_time);
                }
            }
        });
    },
    //组织视图模板
    render: function () {
        //加载主模板
        $('#page-body', this.el).html(this.template.templateMain(this.model.toJSON()));
        $('#lablelist', this.el).html(this.template.templateLablelist(this.model.toJSON()));
        this.setPagination();
        this.afterRender();
        return this;
    }
});

/************生成页面************/
var container = new Container({
    el: '#container'
});