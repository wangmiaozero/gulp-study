/**
 * Created by AnThen on 2016-7-20.
 * 微信接入 es6+react版
 */
'use strict';//严格模式

/*构造页面*/
import Layout from 'module/layout/layout';

/*先创建布局*/
const layout = new Layout({
    index: 1,
    leftMenuCurName:'微信接入'
});

/********模块********/
/*加载echarts*/
var EChartsAxis = require('module/echarts/echarts-axis.js');

/********本页全局公用变量********/

/********编写页面模块********/
/****二级头部****/
class SubHead extends React.Component{
    render(){
        return(
            <header className="page-body-header">
                <div className="text-box">
                    <span className="title">微信接入</span>
                    <span className="text">
                        已对接公众号<span className="variable">{this.props.data.service + this.props.data.subscribe}</span>个，个人号<span className="variable">{this.props.data.someone}</span>个
                    </span>
                </div>
            </header>
        );
    }
}
/****公共号接入 and 个人号接入****/
class Access extends React.Component{
    render(){
        return(
            <div className="con-top">
                <Mass />
                <Someone />
            </div>
        )
    }
}
/*公共号接入*/
class Mass extends React.Component{
    fetch(){
        let that = this;
        util.api({
            url: "?method=mkt.data.inbound.wechat.public.auth",
            type: 'get',
            data: {},
            success: function (res) {
                if(res.code == 0){
                    that.setState({href:res.data[0].url});
                }
            }
        });
    }
    constructor(props){
        super(props);
        this.state = {
            ul:[
                '1. 进行粉丝的管理',
                '2. 进行粉丝的细分',
                '3. 精确触达的粉丝',
                '4. 匹配并放大粉丝群体'
            ],
            href:''
        };
    }
    componentDidMount(){
        this.fetch();
    }
    render(){
        return(
            <div className="mass">
                <div className="thiscon">
                    <div className="title">公共号接入</div>
                    <div className="h2">完整授权后将可以</div>
                    <ul>
                        {this.state.ul.map((m,i)=> {
                            return (<li className="li">{m}</li>)
                        })}
                    </ul>
                </div>
                <div className="butorqr-box">
                    <a className="but" href={this.state.href} target="_blank">授权接入</a>
                </div>
            </div>
        )
    }
}
/*个人号接入*/
class Someone extends React.Component{
    fetch(){
        let obj;
        /*生成二维码13942093706徐宁*/
        h5Persona.login().then(function(obj) {
            obj = obj.data;
            $('#qrcode').qrcode({width: 112,height: 112,text: obj.qrstring});
            //.checklogin方法检查二维码是否被扫描并登录
            h5Persona.checkLogin(function(result) {
                util.api({
                    url: "?method=mkt.data.inbound.wechat.personal.auth",
                    type: 'post',
                    data: {'uuid': obj.uuid,'uin': result},
                    success: function (res) {
                        if(res.code == 0){location.reload() }
                    }
                });
            });
        });
    }
    constructor(props){
        super(props);
        this.state = {
            ul:[
                '1. 把好友当作资源补充到业务人群',
                '2. 在营销中点对点或群体的触达好友',
                '3. 分析好友行为',
                '4. 识别好友间的关系'
            ],
            href:''
        };
    }
    componentDidMount(){
        //this.fetch();
    }
    render(){
        return(
            <div className="someone">
                <div className="thiscon">
                    <div className="title">个人号接入</div>
                    <div className="h2">扫描右侧二维码托管个人号将可以</div>
                    <ul>
                        {this.state.ul.map((m,i)=> {
                            return (<li className="li">{m}</li>)
                        })}
                    </ul>
                </div>
                <div className="butorqr-box"style={{width:'auto'}}><div className="qr-code" id="qrcode" style={{width:'260px',lineHeight:'112px'}}>小V机器人正在升级中，敬请期待...</div></div>
            </div>
        )
    }
}

/****微信接入监测****/
class Monitor extends React.Component{
    render(){
        return(
            <div className="con-bottom">
                <div className="title">微信接入监测</div>
                <div className="monitor-area">
                    <Echarts />
                    <List service={this.props.service} someone={this.props.someone} subscribe={this.props.subscribe}/>
                </div>
            </div>
        )
    }
}
/*echarts*/
class Echarts extends React.Component{
    fetch(){
        let myChart = echarts.init(document.getElementById('chartstop'));
        myChart.showLoading();
        let data;
        let xAxis,series=new Array(),j=0;
        let chartsData = {
            div:myChart,
            divId:$('#chartstop'),
            title:'',
            backgroundColor: ['#5bd4c7', '#8bc34a', '#64b5f6'],
            formatter: '{b}：{c}人',
            xAxis:[],
            yAxisUnit:'{value} 人',
            series:[]
        };
        util.api({
            data: {method: 'mkt.wechat.user.list'},
            success: function (res) {
                if(res.code == 0){
                    data = res.data;
                    if(data.length > 0){
                        for(let i=0; i<data.length; i++){
                            if(data[i].name == 'date'){
                                xAxis = data[i].value_data;
                            }else{
                                series[j] = {name:data[i].name,data:data[i].value_data};
                                j++;
                            }
                        }
                        chartsData.xAxis = xAxis;
                        chartsData.series = series;
                    }
                    EChartsAxis.axis(chartsData);
                }
            }
        });
    }
    constructor(props){
        super(props);
        this.state = {};
    }
    componentDidMount(){
        this.fetch();
    }
    render(){
        return(
            <div className="monitor-box" id="chartstop"></div>
        )
    }
}
/*微信接入列表*/
class List extends React.Component{
    render(){
        return(
            <div className="list-area">
                <div className="list-title">微信接入列表</div>
                <div className="list-box">
                    <div className="type-title">服务号</div>
                    <div className="ul">
                        {this.props.service.map((m,i)=> {
                            return (
                                <div className="li">
                                    <span className="text">{m.name}({m.count})</span><span className="ico"></span>
                                </div>
                            )
                        })}
                    </div>
                </div>
                <div className="list-box">
                    <div className="type-title">订阅号</div>
                    <div className="ul">
                        {this.props.subscribe.map((m,i)=> {
                            return (
                                <div className="li">
                                    <span className="text">{m.name}({m.count})</span><span className="ico"></span>
                                </div>
                            )
                        })}
                    </div>
                </div>
                <div className="list-box">
                    <div className="type-title">个人号</div>
                    <div className="ul">
                        {this.props.someone.map((m,i)=> {
                            return (
                                <div className="li">
                                    <span className="text">{m.name}({m.count})</span><span className="ico"></span>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        )
    }
}

/********组织页面模块********/
class Manage extends React.Component {
    fetchService(size){
        let that = this;
        let listData =  new Array();
        util.api({
            url: "?method=mkt.asset.wechat.type.list.get",
            type: 'get',
            data: {'asset_type':0,'index':1,'size':size},
            success: function (res) {
                if(res.code == 0){
                    for(let i=0; i<res.total; i++){
                        listData[i]={
                            name:res.data[i].asset_name || '',
                            count:res.data[i].follower_count || 0
                        };
                    }
                    that.setState({serviceList:listData});
                }
            }
        });
    }
    fetchSubscribe(size){
        let that = this;
        let listData =  new Array();
        util.api({
            url: "?method=mkt.asset.wechat.type.list.get",
            type: 'get',
            data: {'asset_type':2,'index':1,'size':size},
            success: function (res) {
                if(res.code == 0){
                    for(let i=0; i<res.total; i++){
                        listData[i]={
                            name:res.data[i].asset_name || '',
                            count:res.data[i].follower_count || 0
                        };
                    }
                    that.setState({subscribeList:listData});
                }
            }
        });
    }
    fetchSomeone(size){
        let that = this;
        let listData =  new Array();
        util.api({
            url: "?method=mkt.asset.wechat.type.list.get",
            type: 'get',
            data: {'asset_type':1,'index':1,'size':size},
            success: function (res) {
                if(res.code == 0){
                    for(let i=0; i<res.total; i++){
                        listData[i]={
                            name:res.data[i].asset_name || '',
                            count:res.data[i].follower_count || 0
                        };
                    }
                    that.setState({someoneList:listData});
                }
            }
        });
    }
    fetch(){
        let that = this;
        let serviceNum,subscribeNum,someoneNum;
        util.api({
            url: "?method=mkt.asset.wechat.type.count.get",
            type: 'get',
            async:true,
            data: {},
            success: function (res) {
                if(res.code == 0){
                    for(var i=0;i<res.total; i++){
                        if(res.data[i].asset_type == '0'){serviceNum = res.data[i].count}
                        if(res.data[i].asset_type == '1'){someoneNum = res.data[i].count}
                        if(res.data[i].asset_type == '2'){subscribeNum = res.data[i].count}
                    }
                    that.setState({
                        num:{
                            service: serviceNum,
                            someone: someoneNum,
                            subscribe: subscribeNum
                        }
                    });
                    that.fetchService(serviceNum);
                    that.fetchSubscribe(subscribeNum);
                    that.fetchSomeone(someoneNum);
                }
            }
        });
    }
    constructor(props){
        super(props);
        this.state = {
            num:{service:0,someone:0,subscribe:0},
            serviceList:[],someoneList:[],subscribeList:[]
        };
    }
    componentDidMount(){
        this.fetch();
    }
    render() {
        return (
            <div className="weixin">
                <SubHead data={this.state.num}/>
                <div className="content">
                    <Access />
                    <Monitor service={this.state.serviceList} someone={this.state.someoneList} subscribe={this.state.subscribeList}/>
                </div>
            </div>
        )
    }
}
/********渲染页面********/
const manage = ReactDOM.render(
    <Manage />,
    document.getElementById('page-body')
);