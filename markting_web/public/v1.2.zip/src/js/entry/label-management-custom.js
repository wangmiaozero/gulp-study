/**
 * Created by AnThen on 2016-5-11.
 */
/*初始化必须的模块*/
'use strict';//严格模式

/*加载模块*/
//加载本页模块
var tpl = require("html/label-management/custom-tpl.html");
//组件
var Modals = require('component/modals.js');
let pagination = require('plugins/pagination')($);//分页插件
/*构造页面*/
var Layout = require('module/layout/layout');
//先创建布局
var layout = new Layout({
    index: 1,
    leftMenuCurName:'自定义标签'
});

var Container = Backbone.View.extend({
    //初始化model
    model: new Backbone.Model(),
    //组织模块
    template:{
        templateMain: _.template($(tpl).filter('#tpl-content').html()),
        templateTbody: _.template($(tpl).filter('#tbody-content').html()),
        templateDropdown: _.template($(tpl).filter('#dropdown-content').html())
    },
    //设置响应事件
    events: {
        "click #showgrouplist": "showgrouplist",//弹出人群中查找
        "mouseover .dropdown-button-more": "showMorelist",
        "click #delete": "delete"
    },
    showgrouplist:function(e){
        var listid = $(e.currentTarget).parents('#morelist').attr('trigger'),
            coverCrowd = $('tr[listid='+listid+']').children('.cover-crowd').text();
        /**
         * 弹出搜索用户窗口
         * 第1个参数e必须传，不然无法显示。
         * 第2个参数是ajax的data和总数
         */
        layout.showgrouplist(e, {
            data:{
                method: "mkt.audience.search.get",
                audience_type: 2,//0全局，1人群，2自定义标签
                audience_id: listid,//人群id
            },
            total_count: coverCrowd//总数，如果没有总数就注释掉这行
        });
    },
    resetMorelist: function(){
        $('#dropdown-box', this.el).html(this.template.templateDropdown(this.model.toJSON()));
        $('.dropdown-button').dropdown({
            inDuration: 300,
            outDuration: 225,
            constrain_width: false,
            hover: false,
            gutter: 0,
            belowOrigin: false
        });
    },
    showMorelist: function(e){
        var that = $(e.currentTarget),
            listid = that.parents('tr').attr('listid');
        $('#morelist').attr('trigger',listid);
        util.api({
            url: "?method=mkt.tag.custom.audience.download",
            type: 'get',
            data: {'tag_id':listid},
            success: function (res) {
                if(res.code == 0){
                    $('#download-file').attr('href',FILE_PATH+res.data[0].download_file_name);
                }else{
                    $('#download-file').attr('href',"javascript:void(0)");
                }
            }
        });
    },
    delete: function(){
        var that = this;
        var index = $('#tbody-box').attr('index'), size = $('#tbody-box').attr('size');
        new Modals.Confirm({
            content:"您确定要删除这个标签吗？",
            listeners:{
                close:function(type){
                    if(type == true){
                        var listid = parseInt($('#morelist').attr('trigger'));
                        util.api({
                            url: "?method=mkt.tag.custom.delete",
                            type: 'post',
                            data: {'tag_id':listid},
                            success: function (res) {
                                if(res.code == 0){
                                    that.fetchTableData(index,size);
                                }
                            }
                        });
                    }else{
                        //console.log("click cancel");
                    }
                }
            }
        });
    },
    initialize: function () {
        var that = this;
        this.render();
        this.model.on('change', function (m) {
            that.render();
        });
        this.fetchTableData(1,7);
    },
    /*配置组件*/
    //表格组件
    fetchTableData: function (index,size) {
        var that = this;
        util.api({
            url: "?method=mkt.tag.custom.list.get",
            type: 'get',
            data: {'index':index,'size':size},
            success: function (res) {
                var tbodyData = new Array();
                if((res.code==0)&&(res.total>0)){
                    for(var i=0; i<res.total; i++){
                        tbodyData[i] = {"id":res.data[i].cover_audience_count,"time":res.data[i].create_time,"name":res.data[i].tag_name,"tag_id":res.data[i].tag_id};
                    }
                    $('#variable-num').text(res.total_count);
                    $('#tbody-box', that.el).html(that.template.templateTbody({tbodyData:tbodyData}));
                    $('.pagination-wrap').pagination('updateItems', res.total_count);
                }else{
                    $('#tbody-box', that.el).html(that.template.templateTbody({tbodyData:tbodyData}));
                    $('.pagination-wrap').pagination('updateItems', 0);
                }
                that.resetMorelist();
                $('#tbody-box').attr({'index':index,'size':size});
            }
        });
    },
    /*实例化分页插件*/
    setPagination() {
        var that = this;
        if ($('.pagination-wrap').length > 0) {
            $('.pagination-wrap').pagination({
                items: 0,//条数
                itemsOnPage: 7,//最多显示页数
                onPageClick: function (pageNumber, event) {
                    that.fetchTableData(pageNumber,7);
                }
            });
        }
    },
    //组织视图模板
    render: function () {
        //加载主模板
        $('#page-body', this.el).html(this.template.templateMain(this.model.toJSON()));
        this.setPagination();
        return this;
    }
});

/************生成页面************/
var container = new Container({
    el: '#container'
});