/**
 * Created by Kolf on 2016-8-8.
 * v1.2
 */
module.exports = {
    baseUrl: '/',
    baseDir: 'm/',
    appName: 'TETEM',
    versions: '1.2.1', //当前版本号
    API_PATH: 'http://mktdevsrv.cssrv.dataengine.com/api',//AJAX路径
    UPLOADAIP_PATH: 'http://mktdevsrv.cssrv.dataengine.com/upload/api',//上传路径
    FILE_PATH: 'http://mktdevsrv.cssrv.dataengine.com/downloads/',//文件下载服务器路径
    BASE_PATH: '',//根路径
    IMG_PATH: '',//图片服务器路径
    //BASE_PATH: '/mkt',//根路径
    //IMG_PATH: '/mkt',//图片服务器路径
    EMPTY_FN: function () {
    }
};