/**
 * Created by 刘晓帆 on 2016-4-11.
 * 折线图
 */
'use strict';

class LineCharts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            title:'用户累计趋势',
            height: 180
        }
        // this.setTotal = this.setTotal.bind(this)
    }

    render() {
        return (
            <div>

            </div>
        )
    }
}