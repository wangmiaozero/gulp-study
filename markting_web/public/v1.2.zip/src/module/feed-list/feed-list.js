/**
 * Created by 刘晓帆 on 2016-4-13.
 */
'use strict';
var React = require('react');
var ReactDOM = require('react-dom');
var style = require('../../css/page/index.scss');