/**
 * Created by 刘晓帆 on 2016-4-11.
 * 头部（）
 */
'use strict';
var tpl = require('./tpl.html');
var tplfnStateList = _.template($(tpl).filter('#tpl-statelist').html());
var tplfnMainsearch = _.template($(tpl).filter('#tpl-mainsearch-list').html());
var Header = Backbone.View.extend({
    template: _.template($(tpl).filter('#tpl-con').html()),
    events: {
        "click .tooltipped": "hidetip",
        "click #status-list .finished": "finishedtask",
        "keyup .search-input": "search",
        "click .search-ico": "searchShow",
        "click .j-backgroundtask": "showBackgroundTask",
        "mouseenter .j-backgroundtask": "fecthTaskList",
        "blur .search-input": "searchHide",
    },
    initialize: function (options) {
        this.options = _.extend({
            index: 0
        }, options || {});
        this.render();

    },
    hidetip:function(){
        $('.material-tooltip').hide();
    },
    showBackgroundTask: function () {
        $('#public-header-red-corner', this.$el).hide();
    },
    fecthTaskList: function () {
        var that = this;

        util.api({
            data: {
                method: 'mkt.task.list.get'
            },
            success: function (responseData) {
                if (responseData.code != 0) {
                    return
                }
                that.$el.find('#status-list ul').html(tplfnStateList({
                    data: responseData.data
                }));
            }
        });
    },

    finishedtask: function () {
        window.location.href = BASE_PATH + '/html/data-supervise/quality-report.html'
    },
    search: function (e) {
        var val = $(e.currentTarget).val().trim();
        var recentlyEl = $('.nodata', this.$el);
        var feedlistEl = $('.search-feeds', this.$el);
        var that = this;
        if (!val)return;
        util.api({
            data: {
                method: "mkt.data.main.search.get",
                name: val
            },

            success: function (res) {
                if (res.code != 0)return;
                if (_.isEmpty(res.data)) {
                    that.$('#search-list .search-feeds').html(`<div class="nodata">
                    <ico class="icon iconfont">&#xe604;</ico>
                    <span>无搜索结果</span>
                </div>`);
                } else {
                    res.data.map(m=> {
                        switch (m.type) {
                            case 0:
                                m.typeName = '人群细分';
                                m.hrefStr = '/html/audience/segment.html?audienceId=' + m.id;
                                break;
                            case 1:
                                m.typeName = '营销活动';
                                m.hrefStr = '/html/activity/plan.html?planId=' + m.id;
                                break;
                            case 2:
                                m.typeName = '人群管理';
                                m.hrefStr = '/html/audience/crowd.html';
                                break;
                        }
                    });
                    that.$('#search-list .search-feeds').html(tplfnMainsearch(res));
                }
            }
        });
    },


    selectBtn: function (e) {
        $('.topmenu-btn', this.$el).eq(this.options.index).addClass('cur');
    },

    searchShow: function (e) {
        this.$('#search-list .search-feeds').html('');
        $('.search-input', this.$el).addClass('show');
    },
    searchHide: function (e) {
        $('.search-input', this.$el).removeClass('show').val('');
    },
    render: function () {
        this.$el.html(this.template(this.options));
        this.selectBtn();
        return this;
    }
});

module.exports = Header;