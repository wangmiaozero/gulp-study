/**
 * Author LLJ
 * Date 2016-4-29 14:10
 */
window.LAYOUTUTILS=require('../../js/util.js');
var Container=require('./view/mainView.js');
/************生成页面************/
   new Container({
        el: '#container'
    });
