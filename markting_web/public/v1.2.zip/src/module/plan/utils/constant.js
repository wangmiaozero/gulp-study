/**
 * Author LLJ
 * Date 2016-6-16 10:43
 */
var obj={
    //刷新频率
    refresh_interval_type_arr:[{val:0,text:"小时"},{val:1,text:"天"},{val:2,text:"周"},{val:2,text:"月"}],
    //关系比较
    attr_comparsion:[{val:1,text:"等于"},{val:2,text:"包含"},{val:3,text:"以特定文本开头"},{val:4,text:"以特定文本结尾"},{val:5,text:"为空"}]
};


module.exports = obj;
