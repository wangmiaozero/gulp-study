/**
 * Author LLJ
 * Date 2016-4-29 14:10
 */
var Container=require('./view/mainView.js');
var container = new Container({
        el: '#container'
});
