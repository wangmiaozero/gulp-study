/**
 * Created by 刘晓帆 on 2016-4-11.
 */
'use strict';
module.exports = {name:'foot'};