class panel extends React.Component{
    constructor(props){
        super(props);
        this.state = { };
    }
    componentDidMount(){
        this.$el = $(React.findDOMNode(this));
    }
    render(){
        let path=BASE_PATH;
        return (
            <div className="button-box icon iconfont">
                <a className="a keyong rui-ico-btn" title="新建表单" id="create-form" title="新建" href={path+"/html/asset/contact-create.html?returnurl=html/asset/contact.html"}>&#xe651;</a>
            </div>
        )

    }
}
module.exports = panel;