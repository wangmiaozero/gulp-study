let Card= require('./list-card.js');
let results=(function(){
    let arr=[];
    for(let i=0;i<12;i++){
        arr.push({
            name:util.uuid()+"",
            id:util.uuid()+"",
            status:Math.round(Math.random()*3),
            count:Math.random()*100000
        })
    }

    return arr
})();
let i=0;
let className="card-wrapper col s3";
class panel extends React.Component{
    constructor(props){
        super(props);
        this.state = {
           'listWrapper': {
               clear: 'both',
               position: 'relative'
           },
            listContent:{
                display: 'block',
                position: 'absolute',
                top: 0,
                left: -10,
                right: -10,
                bottom: 0
            }
        };
    }
    componentDidMount(){
        this.$el = $(React.findDOMNode(this));
    }
    componentWillUpdate(){
        let _this=this;
        i=0;
    }
    delCard(id){
        this.props.delCard(id);
    }
    componentDidUpdate(){
    }
    render(){
        let _this=this;
        return (
            <div className="list-wrapper">
                <div className="list-content row">
                      {
                          this.props.data.length?this.props.data.map(function(result) {
                              i++;
                              if(i==0||(i-1)%4==0) {
                                 className="card-content  mr10";
                             }else if(i%4==0){
                                  className="card-content  ml10";
                              }else{
                                 className="card-content  mr10 ml10";
                              }
                              className+=(result.contact_status==0||result.contact_status==2)?' disabled':'';
                             return <Card className={className} data={result}
                                 delCard={_this.props.delCard}
                                 copyCard={_this.props.copyCard}
                                 page2Preview={_this.props.page2Preview}
                                 page2Feedback={_this.props.page2Feedback}
                                 page2Edit={_this.props.page2Edit}
                             />;
                          }):(function(){return (<div style={{'text-align':'center'}}>暂无数据</div>) })()
                      }
                </div>
            </div>
        )

    }
}
module.exports = panel;