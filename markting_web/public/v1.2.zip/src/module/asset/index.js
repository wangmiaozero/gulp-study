/**
 * Author LLJ
 * Date 2016-5-11 13:40
 */
var Container=require("./view/asset-graphic.js");
$(function(){
    /************生成页面************/
    var container = new Container({
        el: '#container'
    });
})
